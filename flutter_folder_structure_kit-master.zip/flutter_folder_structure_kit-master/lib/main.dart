import 'package:flutter/material.dart';
import 'package:t_store/app.dart';

void main() {
  runApp(const App());
}