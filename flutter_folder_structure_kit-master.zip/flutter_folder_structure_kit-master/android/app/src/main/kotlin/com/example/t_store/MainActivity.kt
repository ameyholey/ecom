package com.example.t_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
